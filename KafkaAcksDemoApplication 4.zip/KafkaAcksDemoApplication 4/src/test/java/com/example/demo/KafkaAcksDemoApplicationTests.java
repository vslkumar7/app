package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.test.context.EmbeddedKafka;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@EmbeddedKafka(partitions = 1, topics = {"demo-topic"})
public class KafkaAcksDemoApplicationTests {

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    public void testSendMessageAcksAll() {
        ResponseEntity<String> response = restTemplate.getForEntity("/send/acksAll/testMessageAll", String.class);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().contains("Sent (acks=all): testMessageAll"));
    }

    @Test
    public void testSendMessageDefaultAcks() {
        ResponseEntity<String> response = restTemplate.getForEntity("/send/default/testMessageDefault", String.class);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().contains("Sent (default ack=1): testMessageDefault"));
    }

}