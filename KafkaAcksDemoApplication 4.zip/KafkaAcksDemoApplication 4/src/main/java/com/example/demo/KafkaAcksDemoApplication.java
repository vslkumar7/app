package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaAcksDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(KafkaAcksDemoApplication.class, args);
    }
}