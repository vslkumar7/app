package com.example.demo;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

@RestController
public class KafkaController {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplateAcksAll;

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplateDefaultAcks;

    @GetMapping("/send/acksAll/{message}")
    public String sendMessageAcksAll(@PathVariable String message) {
        long start = System.currentTimeMillis();
        kafkaTemplateAcksAll.send("demo-topic", message).whenComplete((result, ex) -> {
            if (ex == null) {
                long latency = System.currentTimeMillis() - start;
                System.out.println("ACKS=ALL SUCCESS in " + latency + "ms: " + result.getRecordMetadata());
            } else {
                System.err.println("ACKS=ALL FAILED: " + ex.getMessage());
            }
        });
        return "Sent (acks=all): " + message;
    }

    @GetMapping("/send/default/{message}")
    public String sendMessageDefault(@PathVariable String message) {
        long start = System.currentTimeMillis();
        kafkaTemplateDefaultAcks.send("demo-topic", message).whenComplete((result, ex) -> {
            if (ex == null) {
                long latency = System.currentTimeMillis() - start;
                System.out.println("DEFAULT ACK=1 SUCCESS in " + latency + "ms: " + result.getRecordMetadata());
            } else {
                System.err.println("DEFAULT ACK=1 FAILED: " + ex.getMessage());
            }
        });
        return "Sent (default ack=1): " + message;
    }
}